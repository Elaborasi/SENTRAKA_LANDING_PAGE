SENTRAKA DIGITAL - LOGO PACK v1.0 (Oktober 2026)
Tagline: Solusi digital untuk bisnis yang lebih maju.

ISI
svg/      Master vektor (wordmark sudah outline, tidak butuh font)
png/      Versi raster transparan
favicon/  16/32/48/180/192/512 px, favicon.ico, favicon.svg
fonts/    Space Grotesk 500/600/700 (woff2, lisensi SIL OFL)

VARIAN
sentraka-logo-primary          Utama, full-color (latar terang)
sentraka-logo-dark             Untuk latar forest/navy
sentraka-logo-mono / -mono-white  Satu warna (navy / putih)
sentraka-logo-horizontal-compact (+ -dark, -mono)  Navbar, header, email signature
sentraka-symbol (+ -dark, -mono, -mono-white)      Simbol saja
sentraka-icon-forest / -light / -white             Ikon aplikasi/avatar
sentraka-modules               Empat modul untuk elemen grafis

WARNA
Forest #0F3D33 | Navy #1E293B | Terracotta #F97316
Sand #D4A574 | Light #F7F5EF | White #FFFFFF

ATURAN SINGKAT
- Ruang kosong minimal 1 modul simbol di semua sisi.
- Ukuran minimum: primary 200 px (40 mm), compact 180 px (36 mm), simbol 16 px (5 mm).
- Jangan meregangkan, memiringkan, memberi efek, atau mengetik ulang wordmark.
- Font dasar materi: Space Grotesk (Bold 700 heading, Regular 400 body, Medium 500 label).
